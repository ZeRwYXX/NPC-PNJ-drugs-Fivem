Config = {


    PointRevente = {
        vector3(743.03, -1641.96, 28.9)
    }
}

TextSellZeRwYXDrugs = "Appuyer sur ~r~[E] ~s~pour ~r~vendre de la drogue ~s~ !", -- Description affiché une fois sur le point

    BlipSellZeRwYXDrugs = false, -- Mettre les blips

    BlipSellZeRwYXDrugsId = 267,
    BlipSellZeRwYXDrugsTaille = 0.7,
    BlipSellZeRwYXDrugsCouleur = 57,
    BlipSellZeRwYXDrugsRange = true,
    BlipSellZeRwYXDrugsName = "Revente de Drogue",

    MarkerType = 1,
    MarkerSizeLargeur = 15.0,
    MarkerSizeEpaisseur = 15.0,
    MarkerSizeHauteur = 0.7,
    MarkerDistance = 30.0,
    MarkerColorR = 0,
    MarkerColorG = 10,
    MarkerColorB = 255,
    MarkerOpacite = 180,
    MarkerSaute = false,
    MarkerTourne = true,




    DrogueMenu = {
         --       Nom du label            Nom de l'item         Prix
        {Nom = "Pochion de opium", Item = "opium_pooch", Price = 138},
        {Nom = "Pochon de Coke", Item = "coke_pooch", Price = 95},
        {Nom = "Pochon de meth", Item = "meth_pooch", Price = 73},
        {Nom = "Pochon de weed", Item = "weed_pooch", Price = 69},
    },

    Drogue = {

    --       Nom du label   Nom de l'item      Prix
        {Nom = "Opium", Item = "opium", Price = 55},
        {Nom = "Coke", Item = "coke", Price = 36},
        {Nom = "Meth", Item = "meth", Price = 27},
        {Nom = "Weed", Item = "weed", Price = 11},
    },

 


 